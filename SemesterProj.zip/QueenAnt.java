


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class QueenAnt extends CommonAnt {
   
    private int food;
    private int theDecider;
    
   
  
    
    public int eat(int food)
    {
        this.food=food-1;
        
        return this.food;
        
    }
    
    public String hatch()
    {
        theDecider=randomNumber.nextInt(100);
        
        if(theDecider>50)
        {   
            
            
            return "forager";
        }
        
        else if(theDecider<25)
        {
             
            return "scout";
            
           
        } 
        
        else
            
          
        return "soldier";
        
        
    }        

   
    
}
