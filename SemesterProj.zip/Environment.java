

import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Stack;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class Environment{
    Random randNumber = new Random(System.nanoTime());
    
    
    ColonyView contain = new ColonyView(27,27);
  
    Square[][] colony = new Square[27][27];
    
    ColonyNodeView[][] guiSquares = new ColonyNodeView[27][27];
    
    QueenAnt queen = new QueenAnt();
    
  
   
    ArrayList<ScoutAnt> scoutAnts = new ArrayList();
    ArrayList<ForagerAnt> foragerAnts = new ArrayList();
    ArrayList<SoldierAnt> soldierAnts = new ArrayList();
    ArrayList<BalaAnt> balaAnts = new ArrayList();
    ArrayList<Integer> soldierSquareChoices = new ArrayList();
    ArrayList<Integer> soldierPriorityChoices = new ArrayList();
    ArrayList<Square> squaresWithPheromone = new ArrayList();
    
    ImageIcon dead = new ImageIcon("src/images/DeadAnt.jpg");
    private int turns=0;
    private int days = 0;
    private int centerX=13;
    private int centerY=13;
    private int initialFood;
    private int balaDecider;
    private int rowSelector;
    private int columnSelector;
    private boolean balaKilledQueen;
    
    
    public ColonyView addSquares()
    {
         
        int max=27;
        
       
        
    
        for(int i=0;i<max;i++)
        {   
            for(int j=0;j<max;j++)
            {
               //creates 729 square objects with different id's
                Square individualSqr = new Square(i,j);
                
                colony[i][j]=individualSqr;
                
                //creates 729 ColonyNodeView objects with different id's 
                ColonyNodeView individualColonyNode = new ColonyNodeView();
                
                guiSquares[i][j]=individualColonyNode;
               
                // adds 729 colonynodeview objects to conatin
                contain.addColonyNodeView(individualColonyNode, i, j);
                
                
                //sets colonynodeview objects id to square objects ID
                guiSquares[i][j].setID(colony[i][j].getId());
                
                
                
            }
           
           
            
        } 
         // returns the container with all the colonynodeViewObjects
        return contain; 
       
        
        
    }
    
    
    
    public void scoutTurn()
    {
         if(scoutAnts!=null)
        {
            
             for (ScoutAnt scoutAnt : scoutAnts) {
                 // increases ants age
                 scoutAnt.age();
                 //adjusts the scout count of the gui view after a turn
                 colony[scoutAnt.x][scoutAnt.y].scoutMoved();
                 guiSquares[scoutAnt.x][scoutAnt.y].setScoutCount(colony[scoutAnt.x][scoutAnt.y].getScoutCount());
                 if (colony[scoutAnt.x][scoutAnt.y].getScoutCount() == 0) {
                     //removes the scout icon after the scout moves
                     guiSquares[scoutAnt.x][scoutAnt.y].hideScoutIcon();
                 }  
                 // sets the scouts new coordinates
                 scoutAnt.move(randNumber.nextInt(8)+1);
                 // updates scout counts
                 colony[scoutAnt.x][scoutAnt.y].setScoutCount();
                 colony[scoutAnt.x][scoutAnt.y].openSquare();
                 guiSquares[scoutAnt.x][scoutAnt.y].setScoutCount(colony[scoutAnt.x][scoutAnt.y].getScoutCount());
                 if (colony[scoutAnt.x][scoutAnt.y].getScoutCount() != 0) {
                     //shows scout Icon after move
                     guiSquares[scoutAnt.x][scoutAnt.y].showScoutIcon();
                 }
                 // opens node view
                 guiSquares[scoutAnt.x][scoutAnt.y].showNode();
                 
                 
             }    
        }
        
    }
    
    public ArrayList squareSelection(int x,int y)
    {
        ArrayList<Square> availableSquares = new  ArrayList();
        
         
         
        for(int modX = x-1; modX<=x+1; modX++)
        {
            if( modX<0|| modX>26)
            {
                continue;
            }
            
            for(int modY=y-1;modY<=y+1;modY++)
            {
                
                if(modY<0||modY>26||modX==x&&modY==y)
                {
                     continue;
                }
                
                availableSquares.add(colony[modX][modY]);
                
                
                
               
               
              
            }  
            
            
            
        }
        
        return availableSquares;
        
    }        
      
    public void foragerTurn()
    {
          if(foragerAnts!=null)
        {
            
           ArrayList<Square> desiredSquares = new ArrayList();
           
           Square previousSquare;
           
           Square newSquare;
           
           for (ForagerAnt foragerAnt : foragerAnts) 
            {
                foragerAnt.age();
                
                
                
                
               if(foragerAnt.foragerFood==0)
                {  
                    ArrayList<Square> immediateSquares = squareSelection(foragerAnt.x,foragerAnt.y);


                    if(!immediateSquares.isEmpty())
                    {        
                        int peak=-1;

                         for (Square immediateSquare : immediateSquares) 
                         {
                                if(!immediateSquare.isOpen||foragerAnt.foragerHistory.contains(immediateSquare))
                                {
                                    continue;
                                }
                                
                            
                                if(immediateSquare.getPheremone()>peak)
                                {
                                    
                                     desiredSquares.clear();
                                     peak=immediateSquare.getPheremone();
                                     
                                    
                                     desiredSquares.add(immediateSquare);


                                }



                                else if(immediateSquare.getPheremone()==peak)
                                {
                                     desiredSquares.add(immediateSquare);

                                }                  
                          }    

                    }


                    if(!desiredSquares.isEmpty())
                    {

                         
                         colony[foragerAnt.x][foragerAnt.y].foragerMoved();
                         guiSquares[foragerAnt.x][foragerAnt.y].setForagerCount(colony[foragerAnt.x][foragerAnt.y].getForagerCount());

                         if(colony[foragerAnt.x][foragerAnt.y].getForagerCount()==0)
                         {
                             guiSquares[foragerAnt.x][foragerAnt.y].hideForagerIcon();
                         }    

                         
                         previousSquare=colony[foragerAnt.x][foragerAnt.y];
                         foragerAnt.history(previousSquare);
                         
                         
                         
                         
                         newSquare=desiredSquares.get(randNumber.nextInt(desiredSquares.size()));
                         
                       
                        
                    
                         foragerAnt.x=newSquare.getRow();
                         foragerAnt.y=newSquare.getColumn();

                         colony[foragerAnt.x][foragerAnt.y].setForagerCount();
                         guiSquares[foragerAnt.x][foragerAnt.y].setForagerCount(colony[foragerAnt.x][foragerAnt.y].getForagerCount());
                         
                         if(colony[foragerAnt.x][foragerAnt.y].getForagerCount()!=0)
                         {
                            guiSquares[foragerAnt.x][foragerAnt.y].showForagerIcon(); 
                         }    
                         
                         // forager takes food from square model updated to reflect gui updated to reflect food changes
                         if(colony[foragerAnt.x][foragerAnt.y].getFood()>0)
                         {
                           int foodAmt= foragerAnt.pickUpFood(colony[foragerAnt.x][foragerAnt.y].getFood());
                           colony[foragerAnt.x][foragerAnt.y].addFood(foodAmt);
                           guiSquares[foragerAnt.x][foragerAnt.y].setFoodAmount(colony[foragerAnt.x][foragerAnt.y].getFood());
                             
                         }    
                         
                         
                    } 
                    
                
                               
                }
               
               else if(foragerAnt.foragerFood==1)
               {    
                
                 
                
                 if(!foragerAnt.foragerHistory.isEmpty())
                 {
                     
                       // adds pheromone amount to model 
                 if(colony[foragerAnt.x][foragerAnt.y].getPheremone()<1000&&!colony[foragerAnt.x][foragerAnt.y].equals(colony[centerX][centerY]))  
                 {
                     colony[foragerAnt.x][foragerAnt.y].addPheremone(foragerAnt.addPheromone(colony[foragerAnt.x][foragerAnt.y].getPheremone()));
                     
                     guiSquares[foragerAnt.x][foragerAnt.y].setPheromoneLevel(colony[foragerAnt.x][foragerAnt.y].getPheremone());
                   
                     if(squaresWithPheromone.indexOf(colony[foragerAnt.x][foragerAnt.y])==-1)
                     {
                       squaresWithPheromone.add(colony[foragerAnt.x][foragerAnt.y]);  
                     }
                         
                     
                     
                 } 
                 
                 
                     colony[foragerAnt.x][foragerAnt.y].foragerMoved();
                      guiSquares[foragerAnt.x][foragerAnt.y].setForagerCount(colony[foragerAnt.x][foragerAnt.y].getForagerCount());

                         if(colony[foragerAnt.x][foragerAnt.y].getForagerCount()==0)
                         {
                             guiSquares[foragerAnt.x][foragerAnt.y].hideForagerIcon();
                         }    
                 

                        foragerAnt.x= foragerAnt.foragerHistory.peek().getRow();
                        foragerAnt.y= foragerAnt.foragerHistory.peek().getColumn();
                        foragerAnt.foragerHistory.pop();

                        colony[foragerAnt.x][foragerAnt.y].setForagerCount();
                        guiSquares[foragerAnt.x][foragerAnt.y].setForagerCount(colony[foragerAnt.x][foragerAnt.y].getForagerCount());

                        if(colony[foragerAnt.x][foragerAnt.y].getForagerCount()!=0)
                        {
                              guiSquares[foragerAnt.x][foragerAnt.y].showForagerIcon(); 
                        }
                        
                        if(colony[foragerAnt.x][foragerAnt.y].equals(colony[13][13]))
                        {
                            int updateQueenFood = foragerAnt.addFood(colony[13][13].getFood());
                            colony[13][13].addFood(updateQueenFood);
                            guiSquares[13][13].setFoodAmount(colony[13][13].getFood());
                            foragerAnt.foragerHistory.clear();
                        }    
                 }
                        
                    
                                        
                }
            }   
            
        }    
        
       
        
    }        
    
 
    public void soldierMovementSelection(SoldierAnt soldierAnt)
    {
        /*
             this algorithim should check if a square is open and if it contains balas
             if it does contain a bala and is open it adds the direction to the priorty movement arraylist
             
        */
       
     
                if((soldierAnt.x>0&&soldierAnt.y>0)&&colony[soldierAnt.x-1][soldierAnt.y-1].isOpen)    
                {   
                     soldierSquareChoices.add(1);
                    
                    if((soldierAnt.x>0&&soldierAnt.y>0)&&colony[soldierAnt.x-1][soldierAnt.y-1].isOpen
                            &&colony[soldierAnt.x-1][soldierAnt.y-1].getBalaCount()>0)
                    {
                        soldierPriorityChoices.add(1);
                        
                    }
                    
                }    
                   
                  
                    if((soldierAnt.x>0)&&colony[soldierAnt.x-1][soldierAnt.y].isOpen)
                    {
                        soldierSquareChoices.add(2);
                        
                         if((soldierAnt.x>0)&&colony[soldierAnt.x-1][soldierAnt.y].isOpen 
                            &&colony[soldierAnt.x-1][soldierAnt.y].getBalaCount()!=0)
                        {
                                soldierPriorityChoices.add(2);
                        }
                  
                    }
                    
                    
                 if((soldierAnt.x>0&&soldierAnt.y<26)&&colony[soldierAnt.x-1][soldierAnt.y+1].isOpen)
                    {
                            soldierSquareChoices.add(3);
                            
                        if((soldierAnt.x>0&&soldierAnt.y<26)&&colony[soldierAnt.x-1][soldierAnt.y+1].isOpen 
                            &&colony[soldierAnt.x-1][soldierAnt.y+1].getBalaCount()!=0)
                        {
                             soldierPriorityChoices.add(3);
                        }
                    
                   
                        
                    }
                 
                 
                   if((soldierAnt.y<26)&&colony[soldierAnt.x][soldierAnt.y+1].isOpen)
                    {
                            soldierSquareChoices.add(4); 
                            
                            if((soldierAnt.y<26)&&colony[soldierAnt.x][soldierAnt.y+1].isOpen 
                                &&colony[soldierAnt.x][soldierAnt.y+1].getBalaCount()!=0)
                            {
                                soldierPriorityChoices.add(4);
                            }
                    
                    
                    }
                    
                   
                  if((soldierAnt.x<26&&soldierAnt.y<26)&&colony[soldierAnt.x+1][soldierAnt.y+1].isOpen)
                    {
                                soldierSquareChoices.add(5); 
                            if((soldierAnt.x<26&&soldierAnt.y<26)&&colony[soldierAnt.x+1][soldierAnt.y+1].isOpen 
                                &&colony[soldierAnt.x+1][soldierAnt.y+1].getBalaCount()!=0)
                            {
                                soldierPriorityChoices.add(5);
                            }   
                    
                  
                    }
                    
                  
                   if((soldierAnt.x<26)&&colony[soldierAnt.x+1][soldierAnt.y].isOpen)
                    {
                                soldierSquareChoices.add(6);
                            if((soldierAnt.x<26)&&colony[soldierAnt.x+1][soldierAnt.y].isOpen 
                                &&colony[soldierAnt.x+1][soldierAnt.y].getBalaCount()!=0)
                            {
                                soldierPriorityChoices.add(6);
                            }
                    
                   
                    }
                   
                   
                   if((soldierAnt.x<26&&soldierAnt.y>0)&&colony[soldierAnt.x+1][soldierAnt.y-1].isOpen)
                    {
                                soldierSquareChoices.add(7); 
                            if((soldierAnt.x<26&&soldierAnt.y>0)&&colony[soldierAnt.x+1][soldierAnt.y-1].isOpen 
                                &&colony[soldierAnt.x+1][soldierAnt.y-1].getBalaCount()!=0)
                            {
                                soldierPriorityChoices.add(7);
                            }
                    
                    
                    }
                   
                   
                  if((soldierAnt.y>0)&&colony[soldierAnt.x][soldierAnt.y-1].isOpen)
                    {
                                soldierSquareChoices.add(8);  
                            if((soldierAnt.y>0)&&colony[soldierAnt.x][soldierAnt.y-1].isOpen 
                                &&colony[soldierAnt.x][soldierAnt.y-1].getBalaCount()!=0)
                            {
                                soldierPriorityChoices.add(8);
                            }
                    
                    
                    }
                    
               else
                        
           for(int i=0;i<8;i++)
           {              
                switch(i)
                {    
                    case 1:     if((soldierAnt.x==0&&soldierAnt.y==0)
                                    && colony[soldierAnt.x+1][soldierAnt.y+1].isOpen
                                    && colony[soldierAnt.x+1][soldierAnt.y+1].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(1);
                                    
                                }
                                
                                else if((soldierAnt.x==0&&soldierAnt.y==0)
                                    && colony[soldierAnt.x+1][soldierAnt.y+1].isOpen)
                                {
                                   soldierSquareChoices.add(1); 
                                } 
                                break;
                    
                    case 2:     if((soldierAnt.x==0&&soldierAnt.y>0&&soldierAnt.y<26)
                                    && colony[soldierAnt.x+1][soldierAnt.y].isOpen
                                    && colony[soldierAnt.x+1][soldierAnt.y].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(2);
                                    
                                }
                                
                                 else if((soldierAnt.x==0&&soldierAnt.y>0&&soldierAnt.y<26)
                                    && colony[soldierAnt.x+1][soldierAnt.y].isOpen)
                                {
                                   soldierSquareChoices.add(2); 
                                } 
                                break;
                    
                    case 3:     if((soldierAnt.x==0&&soldierAnt.y==26)
                                    && colony[soldierAnt.x+1][soldierAnt.y-1].isOpen
                                    && colony[soldierAnt.x+1][soldierAnt.y-1].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(3);
                                    
                                }
                                
                                
                                else if((soldierAnt.x==0&&soldierAnt.y==26)
                                    && colony[soldierAnt.x+1][soldierAnt.y-1].isOpen)
                                {
                                   soldierSquareChoices.add(3); 
                                }
                                
                                break;
                    
                    
                    case 4:     if((soldierAnt.y==26&&soldierAnt.x>0&&soldierAnt.x<26)
                                    && colony[soldierAnt.x][soldierAnt.y-1].isOpen
                                    && colony[soldierAnt.x][soldierAnt.y-1].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(4);
                                    
                                }
                                
                                 else if((soldierAnt.y==26&&soldierAnt.x>0&&soldierAnt.x<26)
                                    && colony[soldierAnt.x][soldierAnt.y-1].isOpen)
                                {
                                   soldierSquareChoices.add(4); 
                                } 
                    
                                break;
                    
                    case 5:     if((soldierAnt.x==26&&soldierAnt.y==26)
                                    && colony[soldierAnt.x-1][soldierAnt.y-1].isOpen
                                    && colony[soldierAnt.x-1][soldierAnt.y-1].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(5);
                                    
                                }
                                
                                else if((soldierAnt.x==26&&soldierAnt.y==26)
                                    && colony[soldierAnt.x-1][soldierAnt.y-1].isOpen)
                                {
                                   soldierSquareChoices.add(5); 
                                }
                                break;
                    
                    case 6:      if((soldierAnt.x==26&&soldierAnt.y>0&&soldierAnt.y<26)
                                    && colony[soldierAnt.x-1][soldierAnt.y].isOpen
                                    && colony[soldierAnt.x-1][soldierAnt.y].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(6);
                                    
                                }
                                
                                 else if((soldierAnt.x==26&&soldierAnt.y>0&&soldierAnt.y<26)
                                    && colony[soldierAnt.x-1][soldierAnt.y].isOpen)
                                {
                                   soldierSquareChoices.add(6); 
                                }
                    
                                break;
                    
                    case 7:     if((soldierAnt.x==26&&soldierAnt.y==0)
                                    && colony[soldierAnt.x-1][soldierAnt.y+1].isOpen
                                    && colony[soldierAnt.x-1][soldierAnt.y+1].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(7);
                                    
                                }
                                
                                else if((soldierAnt.x==26&&soldierAnt.y==0)
                                    && colony[soldierAnt.x-1][soldierAnt.y+1].isOpen)
                                {
                                   soldierSquareChoices.add(7); 
                                }
                    
                                break;
                    
                    case 8:     if((soldierAnt.y==0&&soldierAnt.x>0&&soldierAnt.x<26)
                                    && colony[soldierAnt.x][soldierAnt.y+1].isOpen
                                    && colony[soldierAnt.x][soldierAnt.y+1].getBalaCount()>0)
                                {
                                    soldierPriorityChoices.add(8);
                                    
                                }
                                
                                 else if((soldierAnt.y==0&&soldierAnt.x>0&&soldierAnt.x<26)
                                    && colony[soldierAnt.x][soldierAnt.y+1].isOpen)
                                {
                                   soldierSquareChoices.add(8); 
                                }
                                
                                break; 
                    
                }         
                
       }       
                
        }
        
          
    
    
    public void soldierTurn()
    {
         if(soldierAnts!=null)
        {
            for (SoldierAnt soldierAnt : soldierAnts) 
            {
                
                
                // increases age
                soldierAnt.age();
                //finds open squares
                soldierMovementSelection(soldierAnt);
                
              
               
                if(colony[soldierAnt.x][soldierAnt.y].getSoldierCount()!=0&&colony[soldierAnt.x][soldierAnt.y].getBalaCount()!=0)
                {    
                    String attackBala = soldierAnt.attack();
                   
                    if(attackBala.equals("hit"))
                    {
                       
                       
                        for (Iterator<BalaAnt> balaIterator = balaAnts.iterator();balaIterator.hasNext();)
                        {
                            BalaAnt balaAnt=balaIterator.next();
                            if(balaAnt.x==soldierAnt.x&&balaAnt.y==soldierAnt.y)
                            {
                                balaIterator.remove();
                                
                             
                               
                                
                                // adjusts colony model to new bala Qty
                                colony[soldierAnt.x][soldierAnt.y].balaMoved();
                                // upddates gui to colony model
                                guiSquares[soldierAnt.x][soldierAnt.y].setBalaCount(colony[soldierAnt.x][soldierAnt.y].getBalaCount());
                                
                                 // checks for other bala ants remaining if none left hides scout icon in gui view
                                if(colony[soldierAnt.x][soldierAnt.y].getBalaCount()==0)
                                {
                                    guiSquares[soldierAnt.x][soldierAnt.y].hideBalaIcon();
                                }
                        
                                
                            }    
                            
                        
                        
                                
                        } 
                    
                    
                    }
                
                
                 
                    break;
                
                }
                
                else
                    
                    if(!soldierPriorityChoices.isEmpty())
                    {
                      
                        
                        
                        //adjusts the soldier count of the gui view after a turn
                        colony[soldierAnt.x][soldierAnt.y].soldierMoved();
                        guiSquares[soldierAnt.x][soldierAnt.y].setSoldierCount(colony[soldierAnt.x][soldierAnt.y].getSoldierCount());
                 
                    if(colony[soldierAnt.x][soldierAnt.y].getSoldierCount()==0)
                    { 
                        //removes the soldier icon after the soldier moves                 
                        guiSquares[soldierAnt.x][soldierAnt.y].hideSoldierIcon();
                    }  
                         // sets the soldier new coordinates
                        soldierAnt.move((int) soldierPriorityChoices.get(randNumber.nextInt(soldierPriorityChoices.size())));
                        soldierPriorityChoices.clear();
                        // updates soldier counts
                        colony[soldierAnt.x][soldierAnt.y].setSoldierCount();
                        // updates gui to colony model count
                        guiSquares[soldierAnt.x][soldierAnt.y].setSoldierCount(colony[soldierAnt.x][soldierAnt.y].getSoldierCount());
                 
                        if(colony[soldierAnt.x][soldierAnt.y].getSoldierCount()!=0)
                        {    
                             //shows soldier Icon after move
                            guiSquares[soldierAnt.x][soldierAnt.y].showSoldierIcon();
                         }
                        
                    }
                
               
                     else  if(!soldierSquareChoices.isEmpty())
                    {
                        //adjusts the soldier count of the gui view after a turn
                        colony[soldierAnt.x][soldierAnt.y].soldierMoved();
                        guiSquares[soldierAnt.x][soldierAnt.y].setSoldierCount(colony[soldierAnt.x][soldierAnt.y].getSoldierCount());
                 
                    if(colony[soldierAnt.x][soldierAnt.y].getSoldierCount()==0)
                    { 
                        //removes the soldier icon after the soldier moves                 
                        guiSquares[soldierAnt.x][soldierAnt.y].hideSoldierIcon();
                    }  
               
                    
                         // sets the soldier new coordinates
                        soldierAnt.move((int) soldierSquareChoices.get(randNumber.nextInt(soldierSquareChoices.size())));
                       
                        soldierSquareChoices.clear();
                        // updates soldier counts
                        colony[soldierAnt.x][soldierAnt.y].setSoldierCount();
                        // updates gui to colony model count
                        guiSquares[soldierAnt.x][soldierAnt.y].setSoldierCount(colony[soldierAnt.x][soldierAnt.y].getSoldierCount());
                 
                        if(colony[soldierAnt.x][soldierAnt.y].getSoldierCount()!=0)
                        {    
                             //shows soldier Icon after move
                            guiSquares[soldierAnt.x][soldierAnt.y].showSoldierIcon();
                         }
                        
                    }
                    
                    
                    
        
            }    
        }
    }     
    
    
    
    
    public void balaTurn()
    {
           
        if(balaAnts!=null)
        {
            for (BalaAnt balaAnt : balaAnts) 
            {
                
                // increases age
                balaAnt.age();
               
                     
                if(colony[balaAnt.x][balaAnt.y].getSoldierCount()!=0&&colony[balaAnt.x][balaAnt.y].getBalaCount()!=0)
                {
                    
                    // stores string returned from balaAnt class that decides hit or miss on attack
                    String attackSuccessSoldier = balaAnt.attack();
                  
                    // deals with the case of a hit
                    if(attackSuccessSoldier.equals("hit"))
                    {
                       
                        
                        // removes affected soldier ant from soldier arraylist
                    
                        for (Iterator<SoldierAnt> it = soldierAnts.iterator();it.hasNext();)
                        {
                            SoldierAnt soldierAnt=it.next();
                            if(soldierAnt.x==balaAnt.x&&soldierAnt.y==balaAnt.y)
                            {
                                it.remove();
                                
                                // adjusts colony model to new soldier Qty
                                colony[balaAnt.x][balaAnt.y].soldierMoved();
                                // upddates gui to colony model
                                guiSquares[balaAnt.x][balaAnt.y].setSoldierCount(colony[balaAnt.x][balaAnt.y].getSoldierCount());
                                
                                 // checks for other soldier ants remaining if none left hides soldier icon in gui view
                                if(colony[balaAnt.x][balaAnt.y].getSoldierCount()==0)
                                {
                                    guiSquares[balaAnt.x][balaAnt.y].hideSoldierIcon();
                                }
                                    
                                break;
                                
                            }   
                        }
                    }    
                    
                    
                    
                    
                    
                }else{
                
                    // checks colony model for scout ant presence
                    if(colony[balaAnt.x][balaAnt.y].getScoutCount()!=0&&colony[balaAnt.x][balaAnt.y].getBalaCount()!=0)
                    {

                        // stores string returned from balaAnt class that decides hit or miss on attack
                        String attackSuccess = balaAnt.attack();
                        
                        // deals with the case of a hit
                        if(attackSuccess.equals("hit"))
                        {
                           

                            // removes affected scout ant from scout arraylist

                            for (Iterator<ScoutAnt> it = scoutAnts.iterator();it.hasNext();)
                            {
                                ScoutAnt scoutAnt=it.next();
                                if(scoutAnt.x==balaAnt.x&&scoutAnt.y==balaAnt.y)
                                {
                                    it.remove();




                                    // adjusts colony model to new scout Qty
                                    colony[balaAnt.x][balaAnt.y].scoutMoved();
                                    // upddates gui to colony model
                                    guiSquares[balaAnt.x][balaAnt.y].setScoutCount(colony[balaAnt.x][balaAnt.y].getScoutCount());

                                     // checks for other scout ants remaining if none left hides scout icon in gui view
                                    if(colony[balaAnt.x][balaAnt.y].getScoutCount()==0)
                                    {
                                        guiSquares[balaAnt.x][balaAnt.y].hideScoutIcon();
                                    }

                                    break;
                                } 

                                

                            }

                        }

                    }else{
                        if(colony[balaAnt.x][balaAnt.y].getForagerCount()!=0&&colony[balaAnt.x][balaAnt.y].getBalaCount()!=0)
                        {

                            // stores string returned from balaAnt class that decides hit or miss on attack
                            String attackSuccessForager = balaAnt.attack();
                            
                            // deals with the case of a hit
                            if(attackSuccessForager.equals("hit"))
                            {
                               

                                // removes affected forager ant from forager arraylist

                                for (Iterator<ForagerAnt> it = foragerAnts.iterator();it.hasNext();)
                                {
                                    ForagerAnt foragerAnt=it.next();
                                    if(foragerAnt.x==balaAnt.x&&foragerAnt.y==balaAnt.y)
                                    {
                                        it.remove();

                                        // adjusts colony model to new forager Qty
                                        colony[balaAnt.x][balaAnt.y].foragerMoved();
                                        // upddates gui to colony model
                                        guiSquares[balaAnt.x][balaAnt.y].setForagerCount(colony[balaAnt.x][balaAnt.y].getForagerCount());

                                         // checks for other forager ants remaining if none left hides forager icon in gui view
                                        if(colony[balaAnt.x][balaAnt.y].getForagerCount()==0)
                                        {
                                            guiSquares[balaAnt.x][balaAnt.y].hideForagerIcon();
                                        }
                                    }
                                    break;
                                }
                            }    

                        }else{
                            if(balaAnt.x==13&&balaAnt.y==13)
                            {

                                // stores string returned from balaAnt class that decides hit or miss on attack
                                String attackSuccess = balaAnt.attack();
                              
                                // deals with the case of a hit
                                if(attackSuccess.equals("hit"))
                                {
                                   balaKilledQueen=true;

                                }

                            }else
                            {


                                // checks if any  ants are in the square before moving
                                if((colony[balaAnt.x][balaAnt.y].getScoutCount()==0)||
                                        (colony[balaAnt.x][balaAnt.y].getSoldierCount()==0)||
                                        (colony[balaAnt.x][balaAnt.y].getForagerCount()==0)||
                                        (balaAnt.x!=13&&balaAnt.y!=13))
                                {


                                    //adjusts the bala count of the gui view after a turn
                                    colony[balaAnt.x][balaAnt.y].balaMoved();
                                    guiSquares[balaAnt.x][balaAnt.y].setBalaCount(colony[balaAnt.x][balaAnt.y].getBalaCount());

                                    if(colony[balaAnt.x][balaAnt.y].getBalaCount()==0)
                                    { 
                                        //removes the bala icon after the bala moves                 
                                        guiSquares[balaAnt.x][balaAnt.y].hideBalaIcon();
                                    }  
                                         // sets the balas new coordinates
                                        balaAnt.move(randNumber.nextInt(8)+1);

                                        // updates bala counts
                                        colony[balaAnt.x][balaAnt.y].setBalaCount();
                                        // updates gui to colony model count
                                        guiSquares[balaAnt.x][balaAnt.y].setBalaCount(colony[balaAnt.x][balaAnt.y].getBalaCount());

                                        if(colony[balaAnt.x][balaAnt.y].getBalaCount()!=0)
                                        {    
                                             //shows scout Icon after move
                                            guiSquares[balaAnt.x][balaAnt.y].showBalaIcon();
                                         }

                                }
                           }
                            
                            
                        }
                        
                    }
                }
                
                
               
                
                
                
                
               
            }
            
        }
          
    }        
    
    
    public void removeDeadAnts()
    {
        // REMOVES DEAD BALAS
        for (Iterator<BalaAnt> balaIterator = balaAnts.iterator();balaIterator.hasNext();)
        {
                     BalaAnt balaAnt=balaIterator.next();
                                                       
                        // checks for maximum life span of 1 year
                    if(balaAnt.getAge()==3650)
                    {
                       
                        // decrements bala count in square model
                        colony[balaAnt.x][balaAnt.y].balaMoved();
                        //updates gui bala count to that of square model
                        guiSquares[balaAnt.x][balaAnt.y].setBalaCount(colony[balaAnt.x][balaAnt.y].getBalaCount());
                        // checks if bala count in model is 0
                        if(colony[balaAnt.x][balaAnt.y].getBalaCount()==0)
                        {
                            // hides bala icon on gui view if bal count is 0
                            guiSquares[balaAnt.x][balaAnt.y].hideBalaIcon();
                        }
                    
                    // removes the specified ant from the array list.
                    balaIterator.remove();
                    
                    
                    }
        
        }
        
        
        for (Iterator<ScoutAnt> scoutIterator = scoutAnts.iterator();scoutIterator.hasNext();)
        {                
            ScoutAnt scoutAnt=scoutIterator.next();
                                    
                // should take care of ants that die of old age
                if(scoutAnt.getAge()==3650)
                {   
                   
                    // updates the gui squares at the specified scout ants coordinates scout count to the colony model which is being decremented
                    colony[scoutAnt.x][scoutAnt.y].scoutMoved();
                    guiSquares[scoutAnt.x][scoutAnt.y].setScoutCount(colony[scoutAnt.x][scoutAnt.y].getScoutCount());
                    //removes the scout icon from the specified gui sqaure based on the colony models scout count
                    if(colony[scoutAnt.x][scoutAnt.y].getScoutCount()==0)
                    {
                        guiSquares[scoutAnt.x][scoutAnt.y].hideScoutIcon();
                    }
                    // removes the specified ant from the array list.
                    
                    scoutIterator.remove();
                }       
        }
        
        for (Iterator<SoldierAnt> soldierIterator = soldierAnts.iterator();soldierIterator.hasNext();)
        {                
            SoldierAnt soldierAnt=soldierIterator.next();
                                    
                // should take care of ants that die of old age
                if(soldierAnt.getAge()==3650)
                {   
                   
                    // updates the gui squares at the specified soldier ants coordinates soldier count to the colony model which is being decremented
                    colony[soldierAnt.x][soldierAnt.y].soldierMoved();
                    guiSquares[soldierAnt.x][soldierAnt.y].setScoutCount(colony[soldierAnt.x][soldierAnt.y].getScoutCount());
                    //removes the soldier icon from the specified gui sqaure based on the colony models soldier count
                    if(colony[soldierAnt.x][soldierAnt.y].getScoutCount()==0)
                    {
                        guiSquares[soldierAnt.x][soldierAnt.y].hideScoutIcon();
                    }
                    // removes the specified ant from the array list.
                    
                    soldierIterator.remove();
                }       
        }
        
        
        for (Iterator<ForagerAnt> foragerIterator = foragerAnts.iterator();foragerIterator.hasNext();)
        {                
            ForagerAnt foragerAnt=foragerIterator.next();
                                    
                // should take care of ants that die of old age
                if(foragerAnt.getAge()==3650)
                {   
                   
                    // updates the gui squares at the specified forager ants coordinates forager count to the colony model which is being decremented
                    colony[foragerAnt.x][foragerAnt.y].foragerMoved();
                    guiSquares[foragerAnt.x][foragerAnt.y].setScoutCount(colony[foragerAnt.x][foragerAnt.y].getScoutCount());
                    //removes the forager icon from the specified gui sqaure based on the colony models forager count
                    if(colony[foragerAnt.x][foragerAnt.y].getScoutCount()==0)
                    {
                        guiSquares[foragerAnt.x][foragerAnt.y].hideScoutIcon();
                    }
                    // removes the specified ant from the array list.
                    
                    foragerIterator.remove();
                }       
        }
        
        
        
        
        
    } 
    
    
    /*
        the method below
        creates continuous time
    */
    
    
    public String startTime()
    {
        
        int years=0;
        int maxSim =73000;
        int daysInYears=365;
        for(turns=1;turns<=maxSim;turns++)
        {
          balaDecider=randNumber.nextInt(100)+1;
            
          days=(turns/10); 
          
          years=days/daysInYears;
          
          // Removes dead ants
          removeDeadAnts();
          
          // removes one piece of food from the queens space and assigns it to int updateFood
          int updateFood = queen.eat(colony[centerX][centerY].getFood());
            
          // sets queens colony square to updated food value
          colony[centerX][centerY].addFood(updateFood);
         // update gui view food count to corresponding coloncenterY square model location food
         guiSquares[centerX][centerY].setFoodAmount(colony[centerX][centerY].getFood());
           
          //73000 turns=20yrs  
          if(updateFood<0||turns==73000)
          {
            JOptionPane.showMessageDialog(null,"The Queen Has Perished","The Simulation Has Ended",JOptionPane.INFORMATION_MESSAGE,dead); 
            
            
            break;
          }
          
          else if(balaKilledQueen==true)
          {
               JOptionPane.showMessageDialog(null,"A bala ant has killed the queen","The Simulation Has Ended",JOptionPane.INFORMATION_MESSAGE,dead); 
               
               
               break;
               
          }    
          
          foragerTurn();
          soldierTurn();
          balaTurn();
          scoutTurn();
          
        
            
          // deals with hatching new ants on first turn of each day and reduces pheremone each day 
          if((turns%10)+1==1)
          {
              if(!squaresWithPheromone.isEmpty())
              {
                 for (Iterator<Square> squareIterator = squaresWithPheromone.iterator();squareIterator.hasNext();)
                 {       
                        Square squaresWithPheromone=squareIterator.next();
                        if(squaresWithPheromone.getPheremone()==0)
                        {
                            squareIterator.remove();
                        }
                        if(squaresWithPheromone.getPheremone()>0)
                        {
                            int  updatePheromone=((colony[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].getPheremone())/2);
                            colony[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].addPheremone(updatePheromone);
                            
                            guiSquares[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].setPheromoneLevel( colony[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].getPheremone());
                            
                        }
                        
                        
                 }
              }    
                
              String typeOfAnt=queen.hatch();
             
              if(typeOfAnt.equals("scout"))
              {
                  ScoutAnt scouts = new ScoutAnt(centerX,centerY);
                   
                  scoutAnts.add(scouts);
                  
                  colony[centerX][centerY].setScoutCount();
                  guiSquares[centerX][centerY].setScoutCount(colony[centerX][centerY].getScoutCount());
                  guiSquares[centerX][centerY].showScoutIcon();
                  
                   
              }
              
               if(typeOfAnt.equals("soldier"))
              {
                  SoldierAnt soldierAnt = new SoldierAnt(centerX,centerY);
                  soldierAnt.setID();
                  
                  soldierAnts.add(soldierAnt);
                  colony[centerX][centerY].setSoldierCount();
                  guiSquares[centerX][centerY].setSoldierCount(colony[centerX][centerY].getSoldierCount());
                  guiSquares[centerX][centerY].showSoldierIcon();
              }
               
               if(typeOfAnt.equals("forager"))
              {
                  ForagerAnt foragerAnt = new ForagerAnt(13,13);
                  
                  foragerAnts.add(foragerAnt);
                  
                 
                  colony[centerX][centerY].setForagerCount();
                  guiSquares[centerX][centerY].setForagerCount(colony[centerX][centerY].getForagerCount());
                  guiSquares[centerX][centerY].showForagerIcon();
                  
                  
              } 
                       
             
               
              
          }
          
       
            // 3% chance of creating bala ant then adds bala to arraylist
            if(balaDecider<=3)
            {
                 BalaAnt bala = new BalaAnt(0,0);           
                 balaAnts.add(bala);
            
                 colony[0][0].setBalaCount();
                 guiSquares[0][0].setBalaCount(colony[0][0].getBalaCount());
                 guiSquares[0][0].showBalaIcon();        
            
            
            
        } 
          
         
         
        
      
           
          
       
          
        } 
        
        return String.valueOf("turns: "+turns+"  Days:"+days+"  Years: "+years);
    
    }
    
    
    
    
    // creates step by step time
    public String stepTime()
    {
        balaDecider=randNumber.nextInt(100)+1;
        days=(turns/10);
        turns++;
        
        //removes dead ants
        removeDeadAnts();
        
        
         // removes one piece of food from the queens space and assigns it to int updateFood
          int updateFood = queen.eat(colony[centerX][centerY].getFood());
            
          // sets queens coloncenterY square to updated food value
          colony[centerX][centerY].addFood(updateFood);
         // update gui view food count to corresponding colony square model location food
         guiSquares[centerX][centerY].setFoodAmount(colony[centerX][centerY].getFood());
           
            
          if(updateFood<0)
          {
            JOptionPane.showMessageDialog(null,"The Queen Has Perished","The Simulation Has Ended",JOptionPane.INFORMATION_MESSAGE,dead);  
            
            
          }
          
          else if(balaKilledQueen==true)
          {
               
              JOptionPane.showMessageDialog(null,"A bala ant has killed the queen","The Simulation Has Ended",JOptionPane.INFORMATION_MESSAGE,dead); 
              
          }
          
        foragerTurn();  
        soldierTurn();  
        balaTurn();  
        scoutTurn();
        
          

          
          
        
        if((turns%10)+1==1)
          {
              
              if(!squaresWithPheromone.isEmpty())
              {
                 for (Iterator<Square> squareIterator = squaresWithPheromone.iterator();squareIterator.hasNext();)
                 {       
                        Square squaresWithPheromone=squareIterator.next();
                        if(squaresWithPheromone.getPheremone()==0)
                        {
                            squareIterator.remove();
                        }
                        if(squaresWithPheromone.getPheremone()>0)
                        {
                            int  updatePheromone=((colony[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].getPheremone())/2);
                            colony[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].addPheremone(updatePheromone);
                            
                            guiSquares[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].setPheromoneLevel( colony[squaresWithPheromone.getRow()][squaresWithPheromone.getColumn()].getPheremone());
                            
                        }
                        
                        
                 }
              }
              
              
             String typeOfAnt=queen.hatch();
              // if queen hatches scout ant creates new scout ant and sets is ID also adds it to the scout ant array list
              if(typeOfAnt.equals("scout"))
              {
                  
                  ScoutAnt scouts = new ScoutAnt(centerX,centerY);
                  scouts.setID();
                  scoutAnts.add(scouts);
                 
                  colony[centerX][centerY].setScoutCount();
                  guiSquares[centerX][centerY].setScoutCount(colony[centerX][centerY].getScoutCount());
                  guiSquares[centerX][centerY].showScoutIcon();
                  
                             
              }
              // if queen hatches soldier ant creates new soldier ant and sets is ID also adds it to the soldier ant array list
               if(typeOfAnt.equals("soldier"))
              {
                  
                  SoldierAnt soldierAnt = new SoldierAnt(centerX,centerY);
                  soldierAnt.setID();
                  
                  soldierAnts.add(soldierAnt);
                  
                  colony[centerX][centerY].setSoldierCount();
                  guiSquares[centerX][centerY].setSoldierCount(colony[centerX][centerY].getSoldierCount());
                  guiSquares[centerX][centerY].showSoldierIcon();
                 
              }
               // if queen hatches forager ant creates new forager ant and sets is ID also adds it to the forager ant array list
               if(typeOfAnt.equals("forager"))
              {
                  ForagerAnt foragerAnt = new ForagerAnt(13,13);
                  foragerAnt.setID();
                  foragerAnts.add(foragerAnt);
                  colony[centerX][centerY].setForagerCount();
                  guiSquares[centerX][centerY].setForagerCount(colony[centerX][centerY].getForagerCount());
                  guiSquares[centerX][centerY].showForagerIcon();
                  
              } 
                   
            
        
              
             
              
              
          }
        
       
            // 3% chance of creating bala ant then adds bala to arraylist
            if(balaDecider<=3)
            {
                 BalaAnt bala = new BalaAnt(0,0);           
                 balaAnts.add(bala);
            
                 colony[0][0].setBalaCount();
                 guiSquares[0][0].setBalaCount(colony[0][0].getBalaCount());
                 guiSquares[0][0].showBalaIcon();        
            
            
            
        } 
        
        
        
        
        
        
        
        
            
        
        return  String.valueOf("turns:  "+turns+"days:  "+days);
    }      
    
    
    
    
    
    public void showFirstView()
    {
        
         scoutAnts.clear();
         foragerAnts .clear();
         soldierAnts .clear();
         balaAnts.clear();
         soldierSquareChoices.clear();
         soldierPriorityChoices.clear();
         squaresWithPheromone.clear();
         turns=0;
         days=0;
         balaKilledQueen=false;
    
        
        for(int i=0;i<27;i++)
        {
            for(int j=0;j<27;j++)
            {
                
                
                colony[i][j].antFood=0;
                colony[i][j].balaQty=0;
                colony[i][j].foragerQty=0;
                colony[i][j].scoutQty=0;
                colony[i][j].soldierQty=0;
                colony[i][j].isOpen=false;
                
                
                guiSquares[i][j].setFoodAmount(0);
                guiSquares[i][j].setBalaCount(0);
                guiSquares[i][j].setForagerCount(0);
                guiSquares[i][j].setScoutCount(0);
                guiSquares[i][j].setSoldierCount(0);
                guiSquares[i][j].hideNode();
                guiSquares[i][j].setPheromoneLevel(0);
                guiSquares[i][j].hideBalaIcon();
                guiSquares[i][j].hideForagerIcon();
                guiSquares[i][j].hideScoutIcon();
                guiSquares[i][j].hideSoldierIcon();
                

            }
            
            
        }
        for(int i=0;i<4;i++)
        {
            ScoutAnt scout = new ScoutAnt(13,13);
            scout.setID();
            scoutAnts.add(scout);
            colony[centerX][centerY].setScoutCount();          
            guiSquares[centerX][centerY].setScoutCount(colony[centerX][centerY].getScoutCount());
            guiSquares[centerX][centerY].showScoutIcon();
        }
        
        for(int i=0;i<10;i++)
        {
            SoldierAnt soldiers = new SoldierAnt(13,13);
            soldiers.setID();
            soldierAnts.add(soldiers);
            colony[centerX][centerY].setSoldierCount();          
            guiSquares[centerX][centerY].setSoldierCount(colony[centerX][centerY].getSoldierCount());
            guiSquares[centerX][centerY].showSoldierIcon();
        }
        
        for(int i=0;i<40;i++)
        {
            ForagerAnt foragers = new ForagerAnt(13,13);
            foragers.setID();
            foragerAnts.add(foragers);
            colony[centerX][centerY].setForagerCount();          
            guiSquares[centerX][centerY].setForagerCount(colony[centerX][centerY].getForagerCount());
            guiSquares[centerX][centerY].showForagerIcon();
            
        }
        
        
        
        
        
        
     
       // makes specified location visible sets model to open
                colony[13-1][13-1].openSquare();
                guiSquares[13-1][13-1].showNode();
                colony[13-1][13].openSquare();
                guiSquares[13-1][13].showNode();
                colony[13-1][13+1].openSquare();
                guiSquares[13-1][13+1].showNode();
                colony[13][13-1].openSquare();
                guiSquares[13][13-1].showNode();
                colony[13][13].openSquare();
                guiSquares[13][13].showNode();
                colony[13][13+1].openSquare();
                guiSquares[13][13+1].showNode();
                colony[13+1][13-1].openSquare();
                guiSquares[13+1][13-1].showNode();
                colony[13+1][13].openSquare();
                guiSquares[13+1][13].showNode();
                colony[13+1][13+1].openSquare();
                guiSquares[13+1][13+1].showNode();
      //sets the queen to the specified location in both cNodeview and Square
      guiSquares[13][13].setQueen(colony[13][13].queenOccupy());
      
      
     
      
      
      // Adds food to specified location of Square class
     colony[13][13].addFood(1000);
     
     
      //Sets the colonynodeview to the amount of food in the corresponding square location
      guiSquares[13][13].setFoodAmount(colony[13][13].getFood());
      // reveals the queenIcon on the colony entrance
      guiSquares[13][13].showQueenIcon();
      queen.setID();
      
 
      
     // 180squares/720squares equals 25% of unopened squares populates those squares with a random amount of food between 500 and 100
      for(int i=0;i<=180;i++)
      {
          
           initialFood=randNumber.nextInt((1000-500)+1)+500;
           rowSelector=randNumber.nextInt(26);
           columnSelector=randNumber.nextInt(26);
           
           if((rowSelector==13&&columnSelector==13)||
                   (rowSelector==12&&columnSelector==13)||
                   (rowSelector==12&&columnSelector==14))
            {
                 rowSelector=randNumber.nextInt(26);
                 columnSelector=randNumber.nextInt(26);
            } 
           
           else if((rowSelector==13&&columnSelector==14)||
                   (rowSelector==14&&columnSelector==14)||
                   (rowSelector==14&&columnSelector==13))
            {
                 rowSelector=randNumber.nextInt(26);
                 columnSelector=randNumber.nextInt(26);
            } 
            
           else if((rowSelector==14&&columnSelector==12)||
                   (rowSelector==13&&columnSelector==12)||
                   (rowSelector==12&&columnSelector==12))
            {
                 rowSelector=randNumber.nextInt(26);
                 columnSelector=randNumber.nextInt(26);
            } 
               
          else
               
                     colony[rowSelector][columnSelector].addFood(initialFood);
           
                    guiSquares[rowSelector][columnSelector].setFoodAmount(colony[rowSelector][columnSelector].getFood());
          
          
      }  
          
      }
    

      
    
    
    
    
}
