/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class BalaAnt extends CommonAnt {
    
   
   
    private int moveDecider;
    private int attackDecider;
    private int cornerDecider;
    private int outSkirtDecider;
    
  
 
   
   public BalaAnt(int x,int y)
   {
      this.x=x;
      this.y=y;
      
       
   }        
   
  
   
   public String attack()
   {
       attackDecider=randomNumber.nextInt(10)+1;
       
       if(attackDecider<=5)
       {
           return "hit";
       }
       
       else
           
           return "miss";
   }        
      
    
}
