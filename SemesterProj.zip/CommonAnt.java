/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
import java.util.Random;
public class CommonAnt {
 public int x;
 public int y;
 public int id=0;
 private int turns=0;
 Random randomNumber = new Random(System.nanoTime());


 
 
 public void setID()
 {
     
     ++id;
 }        

 
 public int getID()
 {
     return id;
 }        
 
 public void age()
 {
     ++turns;
                 
     
 }
 
 public int getAge()
 {
     return turns; 
 }
 
 protected int MoveAndTurnAtGridTop(int x){
    if(x==0){
        x++;
    }else{
        x--;
    }
  return x;
}
 
protected int MoveAndTurnAtGridBottom(int x){
    if(x==26){
        x--;
    }else{
        x++;
    }
  return x;
}

protected int MoveAndTurnAtGridLeft(int y){
    if(y==0){
        y++;
    }else{
        y--;
    }
  return y;
}
 
 protected int MoveAndTurnAtGridRight(int y){
    if(y==26){
        y--;
    }else{
        y++;
    }
  return y;
}
 
protected void move(int direction) {

    switch (direction){
          case 1:
              x = MoveAndTurnAtGridTop(x);
              y = MoveAndTurnAtGridLeft(y);
          break;
          case 2:
              x = MoveAndTurnAtGridTop(x);
          break;
          case 3:
              x = MoveAndTurnAtGridTop(x);
              y = MoveAndTurnAtGridRight(y);
          break;
          case 4:
              y = MoveAndTurnAtGridRight(y);
          break;
          case 5:
              x = MoveAndTurnAtGridBottom(x);
              y = MoveAndTurnAtGridRight(y);
          break;
          case 6:
              x = MoveAndTurnAtGridBottom(x);
          break;
          case 7:
              x = MoveAndTurnAtGridBottom(x);
              y = MoveAndTurnAtGridLeft(y);
          break;
          case 8:
              y = MoveAndTurnAtGridLeft(y);
          break;
          
      }
}
 
     
  
 
    
    
}
