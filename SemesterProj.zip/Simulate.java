/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class Simulate implements SimulationEventListener{
     AntSimGUI simGui = new AntSimGUI();
     Environment env = new Environment();
     
     ColonyView col = env.addSquares();
     
     SimulationEvent firstEvent = new SimulationEvent(this, SimulationEvent.NORMAL_SETUP_EVENT);
     SimulationEvent runEvent = new SimulationEvent(this, SimulationEvent.RUN_EVENT);
     SimulationEvent stepEvent = new SimulationEvent(this, SimulationEvent.STEP_EVENT);
     
     
        
        
        
      public void start()
      {        
        simGui.initGUI(col);
        simGui.addSimulationEventListener(this);
        
               
         
        
        
      }
  
     
     
       @Override
    public void simulationEventOccurred(SimulationEvent simEvent) {
        if(simEvent.getEventType()==SimulationEvent.NORMAL_SETUP_EVENT)
        {  
            
            
            
            env.showFirstView();
            simGui.setTime("");
                 
        }
        
        else if(simEvent.getEventType()==SimulationEvent.RUN_EVENT)
        {
           simGui.setTime(env.startTime());
        }
        
        else if(simEvent.getEventType()==SimulationEvent.STEP_EVENT)
        {
           simGui.setTime(env.stepTime());
        }
        
        else
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
    
      
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       Simulate go = new Simulate();
       go.start();
      
    }

  
    
}
