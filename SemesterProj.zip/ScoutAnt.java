


 





/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class ScoutAnt extends CommonAnt {
   
   
     private int moveDecider;
    private int cornerDecider;
    private int outSkirtDecider;
 
   
   public ScoutAnt(int x,int y)
   {
      this.x=x;
      this.y=y;
      
       
   }        
   
  
}