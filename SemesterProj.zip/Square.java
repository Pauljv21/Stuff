


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class Square {
    
    public int antFood=0;
    private int antPheremone=0;
    private final int row;
    private final int column;
    public int balaQty,foragerQty,scoutQty,soldierQty;
    private boolean queenHome;
    public boolean isOpen;
    
    
    
   
   public Square(int x,int y)
   {
       row=x;
       column=y;
       
   }        
    /**
     *
     * @param amtFood
     */
    public void addFood(int amtFood)
    {
       antFood=amtFood; 
       
    }
     
    public int getFood()
    {
        return antFood;
    }
    
    /**
     *
     * @param amtPheremone
     */
    public void addPheremone(int amtPheremone)
    {
        antPheremone=amtPheremone;
    }
    
    public int getPheremone()
    {
        return antPheremone;
    } 
    
    
    public String getId()
    {
        return String.valueOf(row+","+column);
    }        
    
    public void setBalaCount()
    {
       ++balaQty;
        
    }
    
    public int getBalaCount()
    {
        return balaQty;
    }
    
    public void balaMoved()
    {
        if(balaQty!=0)
        {    
             --balaQty; 
        }
        
        else 
            balaQty=0;
           
        
    }
    
    public void setSoldierCount()
    {
        ++soldierQty;
    }        
    
    public int getSoldierCount()
    {
        return soldierQty;
    }
    
     public void soldierMoved()
    {
        if(soldierQty!=0)
        {    
             --soldierQty; 
        }
        
        else 
            soldierQty=0;
           
        
    }
    
    
  
    public void setForagerCount()
    {
        ++foragerQty;
    }
    
    public int getForagerCount()
    {
        return foragerQty;
    }
    
     public void foragerMoved()
    {
        if(foragerQty!=0)
        {    
             --foragerQty; 
        }
        
        else 
            foragerQty=0;
           
        
    }
    
    public void setScoutCount()
    {
        ++scoutQty;
    }
    
    public int getScoutCount()
    {
        return scoutQty;
    }        
    public void scoutMoved()
    {
        if(scoutQty!=0)
        {    
             --scoutQty; 
        }
        
        else 
            scoutQty=0;
           
        
    }
    
    
    
    public boolean queenOccupy()
    {
        queenHome=true;
        return queenHome;
    }
    
    public int getRow()
    {
        return row;
    }        
    
    public int getColumn()
    {
        return column;
    } 
   
    public void openSquare()
    {
        isOpen=true;
    }        
    
    
    
}
