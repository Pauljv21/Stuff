
import java.util.Stack;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class ForagerAnt extends CommonAnt {
   
    public int foragerFood;
    Stack<Square> foragerHistory=new Stack(); 
    public ForagerAnt(int x,int y)
   {
      this.x=x;
      this.y=y;
      
       
   }
    
   public void history(Square history)
   {
       
       foragerHistory.add(history);
       
   
       
   }        
   public int pickUpFood(int food)
   {
       
            
            foragerFood=1;
            
            food=food-1;
        
            return food;
   }
   
   public int addFood(int food)
   {
       foragerFood=foragerFood-1;
        
        return food+1;
   }
   
   public int addPheromone(int pheromone)
   {
       return pheromone+10;
   }        
        
        
             
    
    
}
